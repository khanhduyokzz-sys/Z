//
//  SceneDelegate.h
//  Cofi
//
//  Created by seo on 3/24/26.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

